# UGLY Server Mods
Learned and copied some stuff from DSMC
https://dsmcfordcs.wordpress.com/

Contains
* Livemap (deactivated)
* Auto ATIS

- Copy USM and Script directory into server's "Saved Games\DCS\" directory
- To start auto atis add MissionStart trigger with doScript = "UglyStartAtis = {}"


