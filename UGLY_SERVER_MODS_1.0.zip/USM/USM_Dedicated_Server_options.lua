-- Ugly Server Mods -- Dedicated server option file

-- Server auto-save options
-- Choosing this option require desanitization of MissionScripting.lua. 
-- If you didn't already done that, USM will do that for you!
-- USM_UseLiveMap		= true		-- true / false. 
-- USM_UseAutoATIS		= true		-- true / false. 

-- Debug. Leave on only for bugtracking!!!
USM_DebugMode	= false		-- true / false


